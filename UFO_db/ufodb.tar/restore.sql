--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.5 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ufodb;
--
-- Name: ufodb; Type: DATABASE; Schema: -; Owner: firstuser
--

CREATE DATABASE ufodb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE ufodb OWNER TO firstuser;

\connect ufodb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: sightings; Type: TABLE; Schema: public; Owner: firstuser
--

CREATE TABLE public.sightings (
    id character varying(100) NOT NULL,
    country character varying(57),
    city character varying(50),
    state character varying(50),
    shape character varying(50),
    details text,
    date date,
    datetime timestamp without time zone NOT NULL
);


ALTER TABLE public.sightings OWNER TO firstuser;

--
-- Name: sightings_id_seq; Type: SEQUENCE; Schema: public; Owner: firstuser
--

CREATE SEQUENCE public.sightings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sightings_id_seq OWNER TO firstuser;

--
-- Name: sightings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: firstuser
--

ALTER SEQUENCE public.sightings_id_seq OWNED BY public.sightings.id;


--
-- Name: sightings id; Type: DEFAULT; Schema: public; Owner: firstuser
--

ALTER TABLE ONLY public.sightings ALTER COLUMN id SET DEFAULT nextval('public.sightings_id_seq'::regclass);


--
-- Data for Name: sightings; Type: TABLE DATA; Schema: public; Owner: firstuser
--

COPY public.sightings (id, country, city, state, shape, details, date, datetime) FROM stdin;
\.
COPY public.sightings (id, country, city, state, shape, details, date, datetime) FROM '$$PATH$$/3574.dat';

--
-- Name: sightings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: firstuser
--

SELECT pg_catalog.setval('public.sightings_id_seq', 1, false);


--
-- Name: sightings sightings_pkey; Type: CONSTRAINT; Schema: public; Owner: firstuser
--

ALTER TABLE ONLY public.sightings
    ADD CONSTRAINT sightings_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

